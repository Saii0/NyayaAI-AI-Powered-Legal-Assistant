# NyayaAI fixes applied

This build was reviewed against the supplied project and corrected for the main backend, security, RAG, infrastructure, and frontend integration failures.

## Main corrections

1. **Frontend conversation IDs**
   - The UI previously generated a random UUID and sent it as `conversationId` before PostgreSQL had created that conversation.
   - The first request now omits `conversationId`; the backend creates the conversation and the returned database UUID is stored for later requests.

2. **RAG search requests**
   - Blank `filterExpression` values are no longer passed to Spring AI `SearchRequest`.
   - This avoids failures caused by an empty filter expression.

3. **Spring AI M6 dependencies**
   - Added the M6 `spring-ai-advisors-vector-store` dependency required by `QuestionAnswerAdvisor`.

4. **JWT / 403 behavior**
   - Invalid or expired Bearer tokens now produce HTTP 401 instead of being silently ignored.
   - Explicit security exception handling was added.
   - The frontend removes an invalid stored token after a 401.

5. **PostgreSQL / Redis local configuration**
   - Docker Compose and local Spring configuration now use matching development credentials.
   - PostgreSQL and Redis ports are exposed so IntelliJ-launched Spring Boot can connect to the containers.

6. **Multipart upload**
   - Removed the manually forced multipart `Content-Type` header from Axios so the browser supplies the correct boundary.
   - Added validation for the number of files in a multi-upload request.

7. **Build configuration**
   - Java 21 compiler release is explicit.
   - Spring milestone repository is declared for the Spring AI M6 dependency line.
   - Duplicate Vite React plugin dependency was removed.

## What still requires your credentials/environment

- OpenAI API key: required for model responses and embeddings.
- Indian Kanoon API token: optional; required only for live Indian Kanoon searches.
- Docker Desktop: required if you use the supplied PostgreSQL/Redis containers.
- Java 21 and Maven: required for a local backend run.
- Node 20.x is the intended frontend runtime.

The supplied environment cannot access Maven/npm registries, so a full dependency-resolving Maven and npm build could not be executed inside this environment. The project source and configuration have nevertheless been corrected and the runtime instructions have been updated.
