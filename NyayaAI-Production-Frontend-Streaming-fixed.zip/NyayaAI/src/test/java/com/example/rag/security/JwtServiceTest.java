package com.example.rag.security;

import org.junit.jupiter.api.Test;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class JwtServiceTest {
    @Test void tokenRoundTrip() {
        JwtService s=new JwtService("01234567890123456789012345678901",3600);
        UUID id=UUID.randomUUID();
        assertEquals(id,s.subject(s.generate(id,"USER")));
    }
}
