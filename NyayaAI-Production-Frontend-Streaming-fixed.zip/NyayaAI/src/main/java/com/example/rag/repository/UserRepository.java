package com.example.rag.repository;

import com.example.rag.model.UserRecord;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public class UserRepository {
    private final JdbcTemplate jdbc;
    public UserRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }
    public Optional<UserRecord> findByEmail(String email) {
        return jdbc.query("select id,email,password_hash,role from users where email=?", rs -> rs.next()
                ? Optional.of(new UserRecord(rs.getObject("id", UUID.class), rs.getString("email"), rs.getString("password_hash"), rs.getString("role")))
                : Optional.empty(), email.toLowerCase());
    }
    public UserRecord create(String email, String passwordHash) {
        UUID id = UUID.randomUUID();
        jdbc.update("insert into users(id,email,password_hash,role) values(?,?,?,'USER')", id, email.toLowerCase(), passwordHash);
        return new UserRecord(id, email.toLowerCase(), passwordHash, "USER");
    }
}
