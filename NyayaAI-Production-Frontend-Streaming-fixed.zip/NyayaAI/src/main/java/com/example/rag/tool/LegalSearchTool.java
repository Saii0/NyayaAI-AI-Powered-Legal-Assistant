package com.example.rag.tool;

import com.example.rag.client.IndianKanoonClient;
import org.springframework.ai.tool.annotation.Tool;import org.springframework.ai.tool.annotation.ToolParam;import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class LegalSearchTool {
 private final IndianKanoonClient client; private final ThreadLocal<List<IndianKanoonClient.LegalSearchResult>> lastResults=new ThreadLocal<>();
 public LegalSearchTool(IndianKanoonClient client){this.client=client;}
 @Tool(name="searchIndianLaw",description="Search Indian legal documents and judgments using the configured legal API. Use for current/external legal information not available in uploaded documents.")
 public String searchIndianLaw(@ToolParam(description="Legal question, statute, section, case name, or legal phrase") String query){
  var results=client.search(query,5); lastResults.set(results); if(results.isEmpty())return "No matching Indian legal documents were found.";
  StringBuilder out=new StringBuilder("Indian legal search results:\n"); for(var r:results) out.append("- ID: ").append(r.documentId()).append(" | Title: ").append(r.title()).append(" | Snippet: ").append(r.snippet()).append('\n'); return out.toString();
 }
 public List<IndianKanoonClient.LegalSearchResult> consumeLastResults(){var r=lastResults.get();lastResults.remove();return r==null?List.of():r;}
}
