package com.example.rag.dto;

public record SourceDto(
        String fileName,
        String documentId,
        String source,
        String contentPreview
) {
}
