package com.example.rag.dto;
public record LegalSourceDto(String documentId, String title, String snippet) {}
