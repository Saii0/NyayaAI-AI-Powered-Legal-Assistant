package com.example.rag.service;

import com.example.rag.dto.ChatRequest;
import com.example.rag.dto.ChatResponse;
import com.example.rag.dto.ChatStreamEvent;
import com.example.rag.dto.SourceDto;
import com.example.rag.repository.ConversationRepository;
import com.example.rag.tool.LegalSearchTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.QuestionAnswerAdvisor;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

@Service
public class ChatService {
    private static final Logger log = LoggerFactory.getLogger(ChatService.class);
    private final ChatClient chatClient;
    private final VectorStore vectorStore;
    private final LegalSearchTool legalSearchTool;
    private final ConversationRepository conversations;
    private final ConversationMemoryService memory;

    public ChatService(ChatClient.Builder builder, VectorStore vectorStore, LegalSearchTool legalSearchTool,
                       ConversationRepository conversations, ConversationMemoryService memory) {
        this.chatClient = builder.build();
        this.vectorStore = vectorStore;
        this.legalSearchTool = legalSearchTool;
        this.conversations = conversations;
        this.memory = memory;
    }

    public ChatResponse chat(ChatRequest request, UUID userId) {
        UUID conversationId = prepareConversation(request, userId);
        String history = conversationHistory(conversationId);
        var prompt = buildPrompt(request, history);
        String answer = prompt.call().content();
        return completeResponse(request, userId, conversationId, answer);
    }

    /**
     * Streams model output as it is produced by Spring AI. The final event contains
     * the persisted conversation id and source metadata.
     */
    public Flux<ChatStreamEvent> stream(ChatRequest request, UUID userId) {
        UUID conversationId = prepareConversation(request, userId);
        String history = conversationHistory(conversationId);
        var prompt = buildPrompt(request, history);
        StringBuilder answer = new StringBuilder();

        return prompt.stream().content()
                .doOnNext(answer::append)
                .map(ChatStreamEvent::token)
                .concatWith(Mono.fromSupplier(() -> {
                    ChatResponse response = completeResponse(request, userId, conversationId, answer.toString());
                    return ChatStreamEvent.done(response.conversationId(), response.documentSources(), response.legalSources());
                }))
                .onErrorResume(error -> {
                    log.error("Streaming chat failed conversationId={} userId={}", conversationId, userId, error);
                    return Flux.just(ChatStreamEvent.error("NyayaAI could not complete the response. Please try again."));
                });
    }

    private UUID prepareConversation(ChatRequest request, UUID userId) {
        UUID conversationId = request.conversationId() == null || request.conversationId().isBlank()
                ? UUID.randomUUID() : parseId(request.conversationId());
        if (request.conversationId() == null || request.conversationId().isBlank()) {
            conversations.create(conversationId, userId);
        } else if (!conversations.belongsToUser(conversationId, userId)) {
            throw new IllegalArgumentException("Conversation not found");
        }
        return conversationId;
    }

    private String conversationHistory(UUID conversationId) {
        return memory.recent(conversationId).stream()
                .map(m -> m.role() + ": " + m.content())
                .reduce("", (a, b) -> a.isBlank() ? b : a + "\n" + b);
    }

    private ChatClient.ChatClientRequestSpec buildPrompt(ChatRequest request, String history) {
        var prompt = chatClient.prompt()
                .system(systemPrompt())
                .user((history.isBlank() ? "" : "Recent conversation:\n" + history + "\n\n")
                        + "Current user question:\n" + request.question());

        if (request.documentsEnabled()) {
            SearchRequest.Builder searchBuilder = SearchRequest.builder()
                    .query(request.question())
                    .topK(request.resolvedTopK())
                    .similarityThreshold(request.resolvedSimilarityThreshold());
            if (request.filterExpression() != null && !request.filterExpression().isBlank()) {
                searchBuilder.filterExpression(request.filterExpression());
            }
            SearchRequest sr = searchBuilder.build();
            prompt = prompt.advisors(QuestionAnswerAdvisor.builder(vectorStore).searchRequest(sr).build());
        }
        if (request.legalToolEnabled()) {
            prompt = prompt.tools(legalSearchTool);
        }
        return prompt;
    }

    private ChatResponse completeResponse(ChatRequest request, UUID userId, UUID conversationId, String answer) {
        var legalResults = legalSearchTool.consumeLastResults();
        conversations.addMessage(conversationId, "user", request.question());
        conversations.addMessage(conversationId, "assistant", answer);
        memory.append(conversationId, "user", request.question());
        memory.append(conversationId, "assistant", answer);

        List<SourceDto> sources = findSources(request.question(), request);
        var legalSources = legalResults.stream()
                .map(r -> new com.example.rag.dto.LegalSourceDto(r.documentId(), r.title(), r.snippet()))
                .toList();

        log.info("Hybrid chat completed conversationId={} userId={} documents={} legalTool={} streaming={}",
                conversationId, userId, request.documentsEnabled(), request.legalToolEnabled(), answer != null);

        return new ChatResponse(conversationId.toString(), answer, sources, legalSources,
                request.legalToolEnabled(), request.documentsEnabled());
    }

    private String systemPrompt() {
        return "You are NyayaAI, an Indian legal information assistant. Use uploaded documents when relevant and use the legal search tool for current/external legal information. Never invent statutes, sections, cases, dates, citations, or legal conclusions. Distinguish retrieved sources from general explanation. If source data is unavailable, say so. Provide legal information, not a substitute for advice from a qualified advocate.";
    }

    private UUID parseId(String id) {
        try {
            return UUID.fromString(id);
        } catch (Exception e) {
            throw new IllegalArgumentException("conversationId must be a valid UUID");
        }
    }

    private List<SourceDto> findSources(String q, ChatRequest r) {
        if (!r.documentsEnabled()) return List.of();
        SearchRequest.Builder searchBuilder = SearchRequest.builder()
                .query(q)
                .topK(r.resolvedTopK())
                .similarityThreshold(r.resolvedSimilarityThreshold());
        if (r.filterExpression() != null && !r.filterExpression().isBlank()) {
            searchBuilder.filterExpression(r.filterExpression());
        }
        SearchRequest sr = searchBuilder.build();
        var docs = vectorStore.similaritySearch(sr);
        if (docs == null) return List.of();
        return docs.stream()
                .map(d -> new SourceDto(
                        String.valueOf(d.getMetadata().getOrDefault("fileName", "uploaded document")),
                        d.getId(),
                        String.valueOf(d.getMetadata().getOrDefault("source", "uploaded document")),
                        d.getText() == null ? "" : d.getText().substring(0, Math.min(300, d.getText().length()))))
                .toList();
    }
}
