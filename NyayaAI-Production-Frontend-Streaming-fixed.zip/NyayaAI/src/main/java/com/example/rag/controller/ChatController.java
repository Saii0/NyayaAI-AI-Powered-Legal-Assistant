package com.example.rag.controller;

import com.example.rag.dto.ChatRequest;
import com.example.rag.dto.ChatResponse;
import com.example.rag.dto.ChatStreamEvent;
import com.example.rag.service.ChatService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import reactor.core.publisher.Flux;

import java.util.UUID;

@RestController
@RequestMapping("/api/chat")
@Tag(name = "Chat", description = "Hybrid RAG + legal tool chat")
public class ChatController {
    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @PostMapping
    @Operation(summary = "Ask NyayaAI using document RAG and/or live legal tool calling")
    public ResponseEntity<ChatResponse> chat(@Valid @RequestBody ChatRequest request, Authentication authentication) {
        return ResponseEntity.ok(chatService.chat(request, UUID.fromString(authentication.getName())));
    }

    @PostMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @Operation(summary = "Stream a NyayaAI answer as Server-Sent Events")
    public Flux<org.springframework.http.codec.ServerSentEvent<ChatStreamEvent>> stream(
            @Valid @RequestBody ChatRequest request, Authentication authentication) {
        return chatService.stream(request, UUID.fromString(authentication.getName()))
                .map(event -> org.springframework.http.codec.ServerSentEvent.<ChatStreamEvent>builder()
                        .event(event.type())
                        .data(event)
                        .build());
    }
}
