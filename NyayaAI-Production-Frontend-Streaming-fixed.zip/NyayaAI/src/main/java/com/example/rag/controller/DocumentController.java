package com.example.rag.controller;

import com.example.rag.dto.UploadResponse;
import com.example.rag.service.DocumentIngestionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Size;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/documents")
@Tag(name = "Documents", description = "Upload and ingest legal reference PDFs into PGVector")
public class DocumentController {
    private final DocumentIngestionService ingestionService;

    public DocumentController(DocumentIngestionService ingestionService) {
        this.ingestionService = ingestionService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Upload a PDF and store its chunks as embeddings in PGVector")
    public ResponseEntity<UploadResponse> upload(
            @Parameter(description = "PDF file, maximum 20 MB")
            @RequestPart("file") @Size(max = 20_000_000) MultipartFile file) {
        var result = ingestionService.ingest(file);
        return ResponseEntity.ok(new UploadResponse(
                file.getOriginalFilename(), result.sourceDocuments(), result.chunksStored(), "Document ingested successfully"));
    }

    @PostMapping(value = "/upload-many", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Upload multiple PDFs")
    public ResponseEntity<java.util.List<UploadResponse>> uploadMany(@RequestPart("files") MultipartFile[] files) {
        if (files == null || files.length == 0) {
            throw new IllegalArgumentException("At least one PDF file is required");
        }
        if (files.length > 10) {
            throw new IllegalArgumentException("You can upload at most 10 PDF files at once");
        }
        var responses = java.util.Arrays.stream(files).map(file -> {
            var result = ingestionService.ingest(file);
            return new UploadResponse(file.getOriginalFilename(), result.sourceDocuments(), result.chunksStored(), "Document ingested successfully");
        }).toList();
        return ResponseEntity.ok(responses);
    }
}
