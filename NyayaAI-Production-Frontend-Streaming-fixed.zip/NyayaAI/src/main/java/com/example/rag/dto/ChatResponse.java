package com.example.rag.dto;
import java.util.List;
public record ChatResponse(String conversationId,String answer,List<SourceDto> documentSources,List<LegalSourceDto> legalSources,boolean legalToolEnabled,boolean documentRagEnabled) {}
