package com.example.rag.dto;

import java.util.List;

/** Server-Sent Event payload emitted by the streaming chat endpoint. */
public record ChatStreamEvent(
        String type,
        String content,
        String conversationId,
        List<SourceDto> documentSources,
        List<LegalSourceDto> legalSources,
        String error
) {
    public static ChatStreamEvent token(String content) {
        return new ChatStreamEvent("token", content, null, List.of(), List.of(), null);
    }

    public static ChatStreamEvent done(String conversationId, List<SourceDto> documentSources,
                                       List<LegalSourceDto> legalSources) {
        return new ChatStreamEvent("done", null, conversationId, documentSources, legalSources, null);
    }

    public static ChatStreamEvent error(String message) {
        return new ChatStreamEvent("error", null, null, List.of(), List.of(), message);
    }
}
