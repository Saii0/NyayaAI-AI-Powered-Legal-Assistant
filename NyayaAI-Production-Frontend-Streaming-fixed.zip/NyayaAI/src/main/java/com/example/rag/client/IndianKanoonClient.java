package com.example.rag.client;

import com.example.rag.exception.LegalApiException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.core.type.TypeReference;

@Component
public class IndianKanoonClient {
    private static final Logger log = LoggerFactory.getLogger(IndianKanoonClient.class);
    private final RestClient restClient; private final ObjectMapper objectMapper; private final String apiToken; private final StringRedisTemplate redis;
    public IndianKanoonClient(ObjectMapper objectMapper,
            @Value("${nyaya.legal-api.base-url:https://api.indiankanoon.org}") String baseUrl,
            @Value("${nyaya.legal-api.token:}") String apiToken,
            @Value("${nyaya.legal-api.connect-timeout:3s}") Duration connectTimeout,
            @Value("${nyaya.legal-api.read-timeout:8s}") Duration readTimeout, StringRedisTemplate redis) {
        this.objectMapper=objectMapper; this.apiToken=apiToken; this.redis=redis;
        var factory=new SimpleClientHttpRequestFactory(); factory.setConnectTimeout(connectTimeout); factory.setReadTimeout(readTimeout);
        this.restClient=RestClient.builder().baseUrl(baseUrl).requestFactory(factory).defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE).build();
    }
        @Retry(name="legalApi")
    @CircuitBreaker(name="legalApi", fallbackMethod="fallbackSearch")
    public List<LegalSearchResult> search(String query, int pageSize) {
        String cacheKey = "nyaya:legal-search:" + Integer.toHexString((query.trim().toLowerCase() + ":" + pageSize).hashCode());
        try {
            String cached = redis.opsForValue().get(cacheKey);
            if (cached != null) return objectMapper.readValue(cached, new TypeReference<List<LegalSearchResult>>() {});
        } catch (Exception cacheEx) { log.warn("Redis legal cache read failed; continuing without cache: {}", cacheEx.getMessage()); }
        if (apiToken == null || apiToken.isBlank()) return List.of(new LegalSearchResult("CONFIGURATION", "Indian Kanoon API token is not configured", "Set INDIAN_KANOON_API_TOKEN before using live legal search."));
        try {
            String body=restClient.get().uri(u -> u.path("/search/").queryParam("formInput", query).queryParam("pagenum",0).queryParam("maxpages",1).build())
                    .header(HttpHeaders.AUTHORIZATION,"Token "+apiToken).retrieve().body(String.class);
            JsonNode root=objectMapper.readTree(body); List<LegalSearchResult> results=new ArrayList<>(); JsonNode docs=root.path("docs");
            if(docs.isArray()) for(JsonNode doc:docs){ if(results.size()>=pageSize) break; results.add(new LegalSearchResult(doc.path("tid").asText(""),doc.path("title").asText("Untitled legal document"),clean(doc.path("headline").asText("")))); }
            try { redis.opsForValue().set(cacheKey, objectMapper.writeValueAsString(results), Duration.ofMinutes(10)); } catch (Exception cacheEx) { log.warn("Redis legal cache write failed; continuing without cache: {}", cacheEx.getMessage()); }
            return results;
        } catch(Exception ex) { throw new LegalApiException("Indian Kanoon search failed",ex); }
    }
    public List<LegalSearchResult> fallbackSearch(String query,int pageSize,Throwable ex){ log.error("Indian Kanoon unavailable after resilience policy: {}",ex.toString()); return List.of(new LegalSearchResult("UNAVAILABLE","Legal data service temporarily unavailable","Please retry shortly; no legal conclusion was generated from this failed lookup.")); }
    private String clean(String v){ return v==null?"":v.replaceAll("<[^>]+>"," ").replaceAll("\\s+"," ").trim(); }
    public record LegalSearchResult(String documentId,String title,String snippet) {}
}
