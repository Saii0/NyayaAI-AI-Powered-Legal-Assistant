package com.example.rag.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public class ConversationRepository {
    private final JdbcTemplate jdbc;
    public ConversationRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public void create(UUID id, UUID userId) {
        jdbc.update("insert into conversations(id,user_id) values(?,?)", id, userId);
    }
    public boolean belongsToUser(UUID conversationId, UUID userId) {
        return Boolean.TRUE.equals(jdbc.query("select exists(select 1 from conversations where id=? and user_id=?)", rs -> rs.next() && rs.getBoolean(1), conversationId, userId));
    }
    public void touch(UUID id) { jdbc.update("update conversations set updated_at=current_timestamp where id=?", id); }
    public void addMessage(UUID conversationId, String role, String content) {
        jdbc.update("insert into messages(conversation_id,role,content) values(?,?,?)", conversationId, role, content);
        touch(conversationId);
    }
    public List<MessageRecord> recentMessages(UUID conversationId, int limit) {
        return jdbc.query("select role,content from (select role,content,created_at from messages where conversation_id=? order by created_at desc limit ?) x order by created_at asc",
                (rs, n) -> new MessageRecord(rs.getString("role"), rs.getString("content")), conversationId, limit);
    }
    public record MessageRecord(String role, String content) {}
}
