package com.example.rag.model;

import java.util.UUID;

public record UserRecord(UUID id, String email, String passwordHash, String role) {}
