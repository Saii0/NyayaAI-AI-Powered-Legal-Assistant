package com.example.rag.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.UUID;

@Repository
public class AuditLogRepository {
    private final JdbcTemplate jdbc;
    public AuditLogRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }
    public void record(String requestId, UUID userId, String action, String path, int status) {
        jdbc.update("insert into audit_logs(request_id,user_id,action,path,status) values(?,?,?,?,?)", requestId, userId, action, path, status);
    }
}
