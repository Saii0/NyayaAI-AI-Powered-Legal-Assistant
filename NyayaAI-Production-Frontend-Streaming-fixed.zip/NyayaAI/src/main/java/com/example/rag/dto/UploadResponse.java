package com.example.rag.dto;

public record UploadResponse(
        String fileName,
        int sourceDocuments,
        int chunksStored,
        String message
) {
}
