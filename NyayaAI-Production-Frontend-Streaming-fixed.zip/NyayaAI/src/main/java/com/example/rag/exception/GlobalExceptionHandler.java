package com.example.rag.exception;

import jakarta.servlet.http.HttpServletRequest;import org.slf4j.Logger;import org.slf4j.LoggerFactory;import org.springframework.http.HttpStatus;import org.springframework.http.ResponseEntity;import org.springframework.security.authentication.BadCredentialsException;import org.springframework.web.bind.MethodArgumentNotValidException;import org.springframework.web.bind.annotation.ExceptionHandler;import org.springframework.web.bind.annotation.RestControllerAdvice;import org.springframework.web.multipart.MaxUploadSizeExceededException;
import java.time.Instant;import java.util.stream.Collectors;

@RestControllerAdvice public class GlobalExceptionHandler {
 private static final Logger log=LoggerFactory.getLogger(GlobalExceptionHandler.class);
 @ExceptionHandler(MethodArgumentNotValidException.class) public ResponseEntity<ErrorResponse> validation(MethodArgumentNotValidException ex,HttpServletRequest r){String m=ex.getBindingResult().getFieldErrors().stream().map(e->e.getField()+": "+e.getDefaultMessage()).collect(Collectors.joining(", "));return build(HttpStatus.BAD_REQUEST,m,r);}
 @ExceptionHandler({IllegalArgumentException.class,IllegalStateException.class}) public ResponseEntity<ErrorResponse> bad(RuntimeException ex,HttpServletRequest r){log.warn("Request failed: {}",ex.getMessage());return build(HttpStatus.BAD_REQUEST,ex.getMessage(),r);}
 @ExceptionHandler(BadCredentialsException.class) public ResponseEntity<ErrorResponse> auth(Exception ex,HttpServletRequest r){return build(HttpStatus.UNAUTHORIZED,"Invalid credentials",r);}
 @ExceptionHandler(MaxUploadSizeExceededException.class) public ResponseEntity<ErrorResponse> max(MaxUploadSizeExceededException ex,HttpServletRequest r){return build(HttpStatus.PAYLOAD_TOO_LARGE,"Uploaded file exceeds the maximum allowed size",r);}
 @ExceptionHandler(LegalApiException.class) public ResponseEntity<ErrorResponse> legal(LegalApiException ex,HttpServletRequest r){return build(HttpStatus.BAD_GATEWAY,ex.getMessage(),r);}
 @ExceptionHandler(Exception.class) public ResponseEntity<ErrorResponse> generic(Exception ex,HttpServletRequest r){log.error("Unhandled application error",ex);return build(HttpStatus.INTERNAL_SERVER_ERROR,"An unexpected error occurred",r);}
 private ResponseEntity<ErrorResponse> build(HttpStatus s,String m,HttpServletRequest r){return ResponseEntity.status(s).body(new ErrorResponse(Instant.now(),s.value(),s.getReasonPhrase(),m,r.getRequestURI(),r.getHeader("X-Request-ID")));}
 public record ErrorResponse(Instant timestamp,int status,String error,String message,String path,String requestId){}
}
