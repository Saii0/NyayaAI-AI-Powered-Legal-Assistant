package com.example.rag.web;

import jakarta.servlet.http.HttpServletRequest;import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;import org.slf4j.LoggerFactory;import org.springframework.data.redis.core.StringRedisTemplate;import org.springframework.security.core.Authentication;import org.springframework.stereotype.Component;import org.springframework.web.servlet.HandlerInterceptor;
import java.time.Duration;

@Component
public class RateLimitInterceptor implements HandlerInterceptor {
 private static final Logger log=LoggerFactory.getLogger(RateLimitInterceptor.class); private static final long LIMIT=60; private final StringRedisTemplate redis;
 public RateLimitInterceptor(StringRedisTemplate redis){this.redis=redis;}
 @Override public boolean preHandle(HttpServletRequest req,HttpServletResponse res,Object handler)throws Exception{
  if(req.getRequestURI().startsWith("/actuator/")||req.getRequestURI().startsWith("/v3/api-docs")||req.getRequestURI().startsWith("/swagger-ui")) return true;
  Authentication a=org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication(); String identity=a!=null&&a.isAuthenticated()?a.getName():req.getRemoteAddr();
  String key="nyaya:ratelimit:"+identity+":"+(System.currentTimeMillis()/60000);
  try{
   Long count=redis.opsForValue().increment(key); if(count!=null&&count==1) redis.expire(key,Duration.ofSeconds(65));
   long remaining=Math.max(0,LIMIT-(count==null?0:count)); res.setHeader("X-RateLimit-Limit",String.valueOf(LIMIT));res.setHeader("X-RateLimit-Remaining",String.valueOf(remaining));
   if(count!=null&&count>LIMIT){res.setStatus(429);res.setHeader("Retry-After","60");return false;}
  }catch(Exception e){log.warn("Redis rate limiter unavailable; failing open: {}",e.getMessage());}
  return true;
 }
}
