package com.example.rag.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public record ChatRequest(
        @NotBlank(message = "question must not be blank")
        String question,

        String conversationId,

        @Min(value = 1, message = "topK must be at least 1")
        @Max(value = 20, message = "topK must not exceed 20")
        Integer topK,

        @DecimalMin(value = "0.0", message = "similarityThreshold must be >= 0")
        @DecimalMax(value = "1.0", message = "similarityThreshold must be <= 1")
        Double similarityThreshold,

        String filterExpression,

        Boolean useDocuments,

        Boolean useLegalTool
) {
    public int resolvedTopK() {
        return topK == null ? 5 : topK;
    }

    public double resolvedSimilarityThreshold() {
        return similarityThreshold == null ? 0.70 : similarityThreshold;
    }

    public boolean documentsEnabled() {
        return useDocuments == null || useDocuments;
    }

    public boolean legalToolEnabled() {
        return useLegalTool == null || useLegalTool;
    }
}
