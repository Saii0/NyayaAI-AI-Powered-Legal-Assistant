package com.example.rag.auth;

import com.example.rag.model.UserRecord;
import com.example.rag.repository.UserRepository;
import com.example.rag.security.JwtService;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UserRepository users; private final PasswordEncoder encoder; private final JwtService jwt;
    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt) { this.users=users; this.encoder=encoder; this.jwt=jwt; }
    public AuthDtos.AuthResponse register(AuthDtos.RegisterRequest r) {
        validatePassword(r.password());
        if (users.findByEmail(r.email()).isPresent()) throw new IllegalArgumentException("Email is already registered");
        UserRecord u;
        try { u=users.create(r.email(), encoder.encode(r.password())); } catch (DuplicateKeyException e) { throw new IllegalArgumentException("Email is already registered"); }
        return new AuthDtos.AuthResponse(jwt.generate(u.id(),u.role()), "Bearer", jwt.expirationSeconds());
    }
    public AuthDtos.AuthResponse login(AuthDtos.LoginRequest r) {
        UserRecord u=users.findByEmail(r.email()).orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));
        if(!encoder.matches(r.password(),u.passwordHash())) throw new IllegalArgumentException("Invalid email or password");
        return new AuthDtos.AuthResponse(jwt.generate(u.id(),u.role()), "Bearer", jwt.expirationSeconds());
    }
    private void validatePassword(String p) { if(p == null || p.length()<12) throw new IllegalArgumentException("Password must be at least 12 characters"); }
}
