package com.example.rag.web;

import org.springframework.context.annotation.Configuration;import org.springframework.web.servlet.config.annotation.InterceptorRegistry;import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration public class WebConfig implements WebMvcConfigurer { private final RateLimitInterceptor limiter; private final com.example.rag.repository.AuditInterceptor audit; public WebConfig(RateLimitInterceptor limiter, com.example.rag.repository.AuditInterceptor audit){this.limiter=limiter;this.audit=audit;} @Override public void addInterceptors(InterceptorRegistry r){r.addInterceptor(limiter).addPathPatterns("/api/**"); r.addInterceptor(audit).addPathPatterns("/api/**");} }
