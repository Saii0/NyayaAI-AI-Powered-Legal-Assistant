package com.example.rag.service;

import com.example.rag.repository.ConversationRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;
import java.util.UUID;

@Service
public class ConversationMemoryService {
    private static final int MAX_MESSAGES = 10;
    private static final Duration TTL = Duration.ofHours(24);
    private final StringRedisTemplate redis;
    private final ConversationRepository repository;
    private final ObjectMapper mapper;
    public ConversationMemoryService(StringRedisTemplate redis, ConversationRepository repository, ObjectMapper mapper) { this.redis=redis; this.repository=repository; this.mapper=mapper; }

    public List<ConversationRepository.MessageRecord> recent(UUID conversationId) {
        String key = key(conversationId);
        try {
            List<String> values = redis.opsForList().range(key, 0, MAX_MESSAGES - 1);
            if (values != null && !values.isEmpty()) return values.stream().map(this::decode).toList();
        } catch (Exception e) { /* Redis is an optimization; PostgreSQL remains the source of truth. */ }
        List<ConversationRepository.MessageRecord> db = repository.recentMessages(conversationId, MAX_MESSAGES);
        if (!db.isEmpty()) {
            try { redis.delete(key); db.forEach(m -> redis.opsForList().rightPush(key, encode(m))); redis.expire(key, TTL); } catch (Exception ignored) {}
        }
        return db;
    }

    public void append(UUID conversationId, String role, String content) {
        String key=key(conversationId);
        try { redis.opsForList().rightPush(key, encode(new ConversationRepository.MessageRecord(role, content))); redis.opsForList().trim(key, -MAX_MESSAGES, -1); redis.expire(key, TTL); } catch (Exception ignored) {}
    }
    private String key(UUID id) { return "nyaya:conversation:" + id; }
    private String encode(ConversationRepository.MessageRecord m) { try { return mapper.writeValueAsString(m); } catch(Exception e) { throw new IllegalStateException(e); } }
    private ConversationRepository.MessageRecord decode(String s) { try { return mapper.readValue(s, ConversationRepository.MessageRecord.class); } catch(Exception e) { throw new IllegalStateException(e); } }
}
