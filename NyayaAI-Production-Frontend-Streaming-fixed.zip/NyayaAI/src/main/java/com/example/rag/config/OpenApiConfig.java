package com.example.rag.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI nyayaAiOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("NyayaAI API")
                .version("1.0")
                .description("Hybrid Indian legal assistant: PDF RAG + Spring AI tool calling."));
    }
}
