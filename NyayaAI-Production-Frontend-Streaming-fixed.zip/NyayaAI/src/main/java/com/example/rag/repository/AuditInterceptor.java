package com.example.rag.repository;

import jakarta.servlet.http.HttpServletRequest;import jakarta.servlet.http.HttpServletResponse;import org.springframework.security.core.Authentication;import org.springframework.stereotype.Component;import org.springframework.web.servlet.HandlerInterceptor;
import java.util.UUID;

@Component public class AuditInterceptor implements HandlerInterceptor {
 private final AuditLogRepository repo; public AuditInterceptor(AuditLogRepository repo){this.repo=repo;}
 @Override public void afterCompletion(HttpServletRequest req,HttpServletResponse res,Object handler,Exception ex){
  try{Authentication a=org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication(); UUID uid=null; if(a!=null&&a.isAuthenticated()) try{uid=UUID.fromString(a.getName());}catch(Exception ignored){} repo.record(org.slf4j.MDC.get("requestId"),uid,req.getMethod(),req.getRequestURI(),res.getStatus());}catch(Exception ignored){}
 }
}
