package com.example.rag.exception;
public class LegalApiException extends RuntimeException { public LegalApiException(String message, Throwable cause){super(message,cause);} public LegalApiException(String message){super(message);} }
