package com.example.rag.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TextSplitter;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class DocumentIngestionService {
    private static final Logger log = LoggerFactory.getLogger(DocumentIngestionService.class);

    private final VectorStore vectorStore;
    private final TextSplitter splitter = new TokenTextSplitter();

    public DocumentIngestionService(VectorStore vectorStore) {
        this.vectorStore = vectorStore;
    }

    public IngestionResult ingest(MultipartFile file) {
        validate(file);
        try {
            ByteArrayResource resource = new NamedByteArrayResource(file.getBytes(), file.getOriginalFilename());
            TikaDocumentReader reader = new TikaDocumentReader(resource);
            List<Document> sourceDocuments = reader.read();

            List<Document> chunks = new ArrayList<>();
            for (Document document : sourceDocuments) {
                var metadata = document.getMetadata();
                metadata.put("source", file.getOriginalFilename());
                metadata.put("fileName", file.getOriginalFilename());
                metadata.put("documentType", "uploaded-document");
                chunks.addAll(splitter.split(document));
            }

            vectorStore.add(chunks);
            log.info("Ingested {}: {} source documents, {} chunks", file.getOriginalFilename(), sourceDocuments.size(), chunks.size());
            return new IngestionResult(sourceDocuments.size(), chunks.size());
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to read uploaded document", ex);
        } catch (Exception ex) {
            throw new IllegalStateException("Document ingestion failed for " + file.getOriginalFilename(), ex);
        }
    }

    private void validate(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File must not be empty");
        }
        String name = file.getOriginalFilename() == null ? "" : file.getOriginalFilename().toLowerCase();
        if (!name.endsWith(".pdf")) {
            throw new IllegalArgumentException("Only PDF files are supported");
        }
        if (file.getSize() > 20_000_000L) {
            throw new IllegalArgumentException("PDF size must not exceed 20 MB");
        }
    }

    public record IngestionResult(int sourceDocuments, int chunksStored) {}

    private static final class NamedByteArrayResource extends ByteArrayResource {
        private final String filename;
        private NamedByteArrayResource(byte[] byteArray, String filename) {
            super(byteArray);
            this.filename = filename == null ? "document.pdf" : filename;
        }
        @Override
        public String getFilename() {
            return filename;
        }
    }
}
