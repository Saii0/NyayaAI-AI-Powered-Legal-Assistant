import axios from 'axios'

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '',
  headers: { 'Content-Type': 'application/json' },
  timeout: 60000,
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('nyaya_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      localStorage.removeItem('nyaya_token')
    }
    return Promise.reject(error)
  },
)

export type SourceDto = {
  fileName: string
  documentId: string
  source: string
  contentPreview: string
}

export type LegalSourceDto = {
  documentId: string
  title: string
  snippet: string
}

export type ChatPayload = {
  question: string
  conversationId?: string
  topK: number
  similarityThreshold: number
  filterExpression?: string
  useDocuments: boolean
  useLegalTool: boolean
}

export type ChatResponse = {
  conversationId: string
  answer: string
  documentSources: SourceDto[]
  legalSources: LegalSourceDto[]
  legalToolEnabled: boolean
  documentRagEnabled: boolean
}

export async function login(email: string, password: string) {
  const { data } = await api.post<{ token: string; tokenType: string; expiresInSeconds: number }>('/api/auth/login', { email, password })
  localStorage.setItem('nyaya_token', data.token)
  return data
}

export async function register(email: string, password: string) {
  const { data } = await api.post<{ token: string; tokenType: string; expiresInSeconds: number }>('/api/auth/register', { email, password })
  localStorage.setItem('nyaya_token', data.token)
  return data
}

export function logout() {
  localStorage.removeItem('nyaya_token')
}

export type StreamEvent = {
  type: 'token' | 'done' | 'error'
  content?: string | null
  conversationId?: string | null
  documentSources?: SourceDto[]
  legalSources?: LegalSourceDto[]
  error?: string | null
}

/**
 * Reads the backend Server-Sent Event stream using fetch so tokens render immediately.
 */
export async function streamChat(
  payload: ChatPayload,
  onEvent: (event: StreamEvent) => void,
  signal?: AbortSignal,
) {
  const token = localStorage.getItem('nyaya_token')
  const response = await fetch(`${import.meta.env.VITE_API_BASE_URL || ''}/api/chat/stream`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'text/event-stream',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(payload),
    signal,
  })

  if (!response.ok) {
    let message = `Request failed (${response.status})`
    try {
      const body = await response.json()
      message = body.message || message
    } catch { /* response was not JSON */ }
    throw new Error(message)
  }

  if (!response.body) throw new Error('Streaming is not supported by this browser.')

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  const consume = (chunk: string) => {
    buffer += chunk.replace(/\r\n/g, '\n')
    const frames = buffer.split('\n\n')
    buffer = frames.pop() ?? ''
    for (const frame of frames) {
      const data = frame.split('\n')
        .filter((line) => line.startsWith('data:'))
        .map((line) => line.slice(5).trimStart())
        .join('\n')
      if (!data || data === '[DONE]') continue
      try { onEvent(JSON.parse(data) as StreamEvent) } catch { /* ignore malformed SSE frame */ }
    }
  }

  while (true) {
    const { value, done } = await reader.read()
    if (done) break
    consume(decoder.decode(value, { stream: true }))
  }
  consume(decoder.decode())
}

export async function uploadDocuments(files: File[]) {
  const form = new FormData()
  files.forEach((file) => form.append('files', file))
  const { data } = await api.post('/api/documents/upload-many', form, {
    timeout: 120000,
  })
  return data
}
