import { useMemo, useRef, useState, type FormEvent } from 'react'
import {
  BookOpen,
  Bot,
  ChevronDown,
  FileText,
  Menu,
  MessageSquarePlus,
  Paperclip,
  Scale,
  Send,
  Settings2,
  Sparkles,
  Upload,
  X,
  LogOut,
} from 'lucide-react'
import { login, logout, register, streamChat, uploadDocuments, type ChatResponse, type SourceDto } from './api'

type Message = {
  id: string
  role: 'user' | 'assistant'
  text: string
  sources?: SourceDto[]
  meta?: ChatResponse
}

type ChatSession = {
  id: string
  backendConversationId?: string
  title: string
  messages: Message[]
}

const starterPrompts = [
  'What is Article 21 of the Constitution of India?',
  'Explain the difference between bail and anticipatory bail.',
  'What remedies are available for breach of contract?',
]

function App() {
  const [authenticated, setAuthenticated] = useState(Boolean(localStorage.getItem('nyaya_token')))
  const [sessions, setSessions] = useState<ChatSession[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [documents, setDocuments] = useState(true)
  const [legalTool, setLegalTool] = useState(true)
  const [topK, setTopK] = useState(5)
  const [threshold, setThreshold] = useState(0.7)
  const [uploadMessage, setUploadMessage] = useState('')
  const fileInput = useRef<HTMLInputElement>(null)

  const active = useMemo(() => sessions.find((s) => s.id === activeId) ?? null, [sessions, activeId])

  if (!authenticated) return <AuthScreen onAuthenticated={() => setAuthenticated(true)} />

  function createChat() {
    const id = crypto.randomUUID()
    setSessions((current) => [{ id, title: 'New legal conversation', messages: [] }, ...current])
    setActiveId(id)
    setInput('')
    setMobileOpen(false)
  }

  function updateSession(id: string, updater: (session: ChatSession) => ChatSession) {
    setSessions((current) => current.map((session) => session.id === id ? updater(session) : session))
  }

  async function submit(question = input) {
    const trimmed = question.trim()
    if (!trimmed || loading) return

    let sessionId = activeId
    if (!sessionId) {
      sessionId = crypto.randomUUID()
      setSessions((current) => [{ id: sessionId!, title: trimmed.slice(0, 42), messages: [] }, ...current])
      setActiveId(sessionId)
    }

    const userMessage: Message = { id: crypto.randomUUID(), role: 'user', text: trimmed }
    const assistantId = crypto.randomUUID()
    updateSession(sessionId, (session) => ({
      ...session,
      title: session.messages.length === 0 ? trimmed.slice(0, 42) : session.title,
      messages: [...session.messages, userMessage, { id: assistantId, role: 'assistant', text: '' }],
    }))
    setInput('')
    setLoading(true)

    try {
      await streamChat({
        question: trimmed,
        ...(sessions.find((session) => session.id === sessionId)?.backendConversationId
          ? { conversationId: sessions.find((session) => session.id === sessionId)?.backendConversationId }
          : {}),
        topK,
        similarityThreshold: threshold,
        useDocuments: documents,
        useLegalTool: legalTool,
      }, (event) => {
        if (event.type === 'token') {
          updateSession(sessionId!, (session) => ({
            ...session,
            messages: session.messages.map((m) => m.id === assistantId ? { ...m, text: m.text + (event.content || '') } : m),
          }))
        } else if (event.type === 'done') {
          updateSession(sessionId!, (session) => ({
            ...session,
            backendConversationId: event.conversationId || session.backendConversationId,
            messages: session.messages.map((m) => m.id === assistantId ? {
              ...m,
              meta: {
                conversationId: event.conversationId || session.backendConversationId || session.id,
                answer: m.text,
                documentSources: event.documentSources || [],
                legalSources: event.legalSources || [],
                legalToolEnabled: legalTool,
                documentRagEnabled: documents,
              },
              sources: event.documentSources || [],
            } : m),
          }))
        } else if (event.type === 'error') {
          throw new Error(event.error || 'Streaming response failed.')
        }
      })
    } catch (error: any) {
      if (error?.name === 'AbortError') return
      if (error?.response?.status === 401 || /401|unauthorized/i.test(error?.message || '')) {
        logout()
        setAuthenticated(false)
        return
      }
      updateSession(sessionId, (session) => ({
        ...session,
        messages: session.messages.map((m) => m.id === assistantId && !m.text ? { ...m, text: `⚠️ ${error?.message || 'Unable to reach NyayaAI.'}` } : m),
      }))
    } finally {
      setLoading(false)
    }
  }

  async function handleUpload(files: FileList | null) {
    if (!files?.length) return
    const selected = Array.from(files).filter((file) => file.type === 'application/pdf')
    if (!selected.length) {
      setUploadMessage('Please choose PDF files.')
      return
    }
    setUploading(true)
    setUploadMessage('Uploading and indexing…')
    try {
      const result = await uploadDocuments(selected)
      const count = Array.isArray(result) ? result.length : 1
      setUploadMessage(`${count} document${count > 1 ? 's' : ''} indexed successfully.`)
    } catch (error: any) {
      setUploadMessage(error?.response?.data?.message || 'Document upload failed.')
    } finally {
      setUploading(false)
      if (fileInput.current) fileInput.current.value = ''
    }
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Open menu"><Menu size={21} /></button>
        <div className="brand"><div className="brand-mark"><Scale size={20} /></div><div><strong>NyayaAI</strong><span>Indian Legal Assistant</span></div></div>
        <div className="top-actions"><span className="status-dot" /> AI service ready <button className="icon-btn" onClick={() => { logout(); setAuthenticated(false) }} title="Sign out"><LogOut size={18} /></button></div>
      </header>

      <div className="workspace">
        <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
          <div className="sidebar-inner">
            <button className="new-chat" onClick={createChat}><MessageSquarePlus size={18} /> New conversation</button>
            <div className="side-label">Conversations</div>
            <div className="session-list">
              {sessions.length === 0 && <div className="empty-sessions">Your conversations will appear here.</div>}
              {sessions.map((session) => (
                <button key={session.id} className={`session ${session.id === activeId ? 'active' : ''}`} onClick={() => { setActiveId(session.id); setMobileOpen(false) }}>
                  <MessageSquarePlus size={16} /><span>{session.title}</span>
                </button>
              ))}
            </div>
            <div className="sidebar-bottom">
              <input ref={fileInput} type="file" accept="application/pdf" multiple hidden onChange={(e) => handleUpload(e.target.files)} />
              <button className="upload-btn" onClick={() => fileInput.current?.click()} disabled={uploading}><Upload size={17} /> {uploading ? 'Indexing…' : 'Upload legal PDFs'}</button>
              {uploadMessage && <div className="upload-message">{uploadMessage}</div>}
              <div className="disclaimer">NyayaAI provides legal information, not legal advice. Verify important matters with a qualified advocate.</div>
            </div>
          </div>
        </aside>
        {mobileOpen && <button className="backdrop" aria-label="Close menu" onClick={() => setMobileOpen(false)} />}

        <main className="chat-area">
          <div className="chat-scroll">
            {!active || active.messages.length === 0 ? (
              <Welcome onPrompt={submit} />
            ) : (
              <div className="messages">
                {active.messages.map((message) => <MessageBubble key={message.id} message={message} />)}
                {loading && <div className="assistant-row"><div className="avatar"><Bot size={17} /></div><div className="typing"><span /><span /><span /></div></div>}
              </div>
            )}
          </div>

          <div className="composer-wrap">
            <div className="composer">
              <button className="attach-btn" onClick={() => fileInput.current?.click()} title="Upload PDF"><Paperclip size={19} /></button>
              <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit() } }} placeholder="Ask a question about Indian law…" rows={1} />
              <button className="send-btn" onClick={() => submit()} disabled={!input.trim() || loading} title="Send"><Send size={18} /></button>
            </div>
            <div className="composer-footer">
              <div className="mode-pills"><span className={legalTool ? 'pill active' : 'pill'}><Sparkles size={13} /> Live legal search</span><span className={documents ? 'pill active' : 'pill'}><FileText size={13} /> Document RAG</span></div>
              <button className="settings-link" onClick={() => setSettingsOpen(!settingsOpen)}><Settings2 size={14} /> Search settings <ChevronDown size={14} /></button>
            </div>
            {settingsOpen && <div className="settings-panel">
              <label><span>Legal tool <b>{legalTool ? 'On' : 'Off'}</b></span><input type="checkbox" checked={legalTool} onChange={(e) => setLegalTool(e.target.checked)} /></label>
              <label><span>Document RAG <b>{documents ? 'On' : 'Off'}</b></span><input type="checkbox" checked={documents} onChange={(e) => setDocuments(e.target.checked)} /></label>
              <label><span>Top results <b>{topK}</b></span><input type="range" min="1" max="20" value={topK} onChange={(e) => setTopK(Number(e.target.value))} /></label>
              <label><span>Similarity <b>{threshold.toFixed(2)}</b></span><input type="range" min="0" max="1" step="0.05" value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} /></label>
            </div>}
          </div>
        </main>
      </div>
    </div>
  )
}

function Welcome({ onPrompt }: { onPrompt: (text: string) => void }) {
  return <div className="welcome">
    <div className="hero-icon"><Scale size={30} /></div>
    <h1>Welcome to <span>NyayaAI</span></h1>
    <p>Your AI-powered assistant for understanding Indian law. Ask questions, search live legal sources, or reason over your uploaded documents.</p>
    <div className="feature-grid"><div><Sparkles size={18} /><strong>Live legal search</strong><span>Use the legal tool for current legal information.</span></div><div><BookOpen size={18} /><strong>Document RAG</strong><span>Ask questions about your uploaded PDFs.</span></div><div><FileText size={18} /><strong>Source-aware</strong><span>See document sources used for your answer.</span></div></div>
    <div className="suggestions"><div className="suggestion-label">Try asking</div>{starterPrompts.map((prompt) => <button key={prompt} onClick={() => onPrompt(prompt)}>{prompt}<Send size={15} /></button>)}</div>
  </div>
}

function MessageBubble({ message }: { message: Message }) {
  return <div className={`message-row ${message.role}`}>
    <div className="avatar">{message.role === 'assistant' ? <Bot size={17} /> : <span>U</span>}</div>
    <div className="message-content"><div className="role-name">{message.role === 'assistant' ? 'NyayaAI' : 'You'}</div><div className="message-text">{message.text.split('\n').map((line, index) => <p key={index}>{line || '\u00a0'}</p>)}</div>
      {message.meta && <div className="source-summary"><span><Sparkles size={13} /> {message.meta.legalToolEnabled ? 'Legal tool enabled' : 'Legal tool off'}</span><span><FileText size={13} /> {message.sources?.length ?? 0} document sources</span></div>}
      {message.sources && message.sources.length > 0 && <div className="sources"><div className="sources-title"><BookOpen size={15} /> Document sources</div>{message.sources.map((source) => <div className="source-card" key={source.documentId}><div className="source-icon"><FileText size={16} /></div><div><strong>{source.fileName}</strong><span>{source.source}</span>{source.contentPreview && <p>{source.contentPreview}</p>}</div></div>)}</div>}
    </div>
  </div>
}

function AuthScreen({ onAuthenticated }: { onAuthenticated: () => void }) {
  const [registerMode, setRegisterMode] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function submitAuth(e: FormEvent) {
    e.preventDefault()
    setBusy(true); setError('')
    try {
      if (registerMode) {
        await register(email, password)
      } else {
        await login(email, password)
      }
      onAuthenticated()
    } catch (err: any) {
      setError(err.message || 'Authentication failed.')
    } finally { setBusy(false) }
  }

  return <div className="auth-page">
    <form className="auth-card" onSubmit={submitAuth}>
      <div className="brand auth-brand"><div className="brand-mark"><Scale size={20} /></div><div><strong>NyayaAI</strong><span>Indian Legal Assistant</span></div></div>
      <h1>{registerMode ? 'Create your account' : 'Welcome back'}</h1>
      <p>Secure access to your AI-powered Indian legal research assistant.</p>
      <label>Email<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
      <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={12} required placeholder="At least 12 characters" /></label>
      {error && <div className="auth-error">{error}</div>}
      <button className="auth-submit" disabled={busy}>{busy ? 'Please wait…' : registerMode ? 'Create account' : 'Sign in'}</button>
      <button type="button" className="auth-switch" onClick={() => { setRegisterMode(!registerMode); setError('') }}>{registerMode ? 'Already have an account? Sign in' : 'Need an account? Register'}</button>
    </form>
  </div>
}

export default App
