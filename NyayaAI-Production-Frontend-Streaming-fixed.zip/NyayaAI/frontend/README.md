# NyayaAI Frontend

**Compatible environment:** Node.js 20.x (tested target: 20.14.x), React 19, Vite 6, TypeScript 5.8.

React + Vite + TypeScript frontend for NyayaAI.

## Features

- JWT login and registration
- Streaming legal chat over Server-Sent Events (SSE)
- Token-by-token rendering from Spring AI
- Hybrid document RAG + live legal tool calling controls
- Conversation sidebar
- PDF document ingestion
- Legal/document source cards
- Responsive desktop and mobile UI

## Local development

```bash
npm install
npm run dev
```

The Vite dev server runs on `http://localhost:5173` and proxies `/api` to the Spring Boot backend on port 8080.

## Production/Docker

From the project root:

```bash
docker compose up --build
```

Open `http://localhost:5173`.
