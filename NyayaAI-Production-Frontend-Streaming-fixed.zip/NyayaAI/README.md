# NyayaAI — Production-Oriented Hybrid Legal AI

NyayaAI is a Spring Boot + Spring AI legal information assistant combining document-grounded RAG with live Indian legal search through tool calling. This version adds the operational building blocks needed for a production deployment: PostgreSQL/PGVector persistence, Redis caching and distributed rate limiting, JWT authentication, resilience policies, audit logging, Actuator, validation, Docker Compose and tests.

## Architecture

```text
Client
  |
  v
Load Balancer / Reverse Proxy
  |
  v
Spring Boot / NyayaAI instances
  |
  +--> Spring Security + JWT
  +--> Rate limiting --> Redis
  +--> ChatService
          |
          +--> Spring AI ChatClient --> OpenAI
          |
          +--> PGVector document retrieval
          |
          +--> LegalSearchTool --> Redis cache --> Indian Kanoon API
          |
          +--> ConversationMemory --> Redis (fast) + PostgreSQL (durable)

PostgreSQL: users, conversations, messages, audit logs, PGVector
Redis: legal API cache, recent conversation cache, rate-limit counters
```

## Main features

- Hybrid RAG + Spring AI tool calling
- OpenAI chat + embeddings
- PGVector document retrieval
- Indian Kanoon live-search tool
- Redis legal-result cache with TTL
- Redis-backed recent conversation memory
- PostgreSQL durable conversation history
- JWT registration/login and protected application endpoints
- BCrypt password hashing
- 60 requests/minute per authenticated user (or client IP before authentication)
- Resilience4j retry + circuit breaker around the legal API
- Request IDs and audit logs
- Spring Boot Actuator health/metrics endpoints
- Bean validation and centralized JSON errors
- Swagger/OpenAPI
- Docker Compose for application + PostgreSQL/PGVector + Redis
- Graceful shutdown and database connection pool settings
- Unit/controller tests

## API

### Register
`POST /api/auth/register`

```json
{"email":"user@example.com","password":"a-strong-password-12"}
```

### Login
`POST /api/auth/login`

```json
{"email":"user@example.com","password":"a-strong-password-12"}
```

Copy the returned JWT and send:

`Authorization: Bearer <token>`

### Chat
`POST /api/chat`

```json
{
  "question": "Explain Article 21 and find relevant Indian legal material.",
  "useDocuments": true,
  "useLegalTool": true,
  "topK": 5,
  "similarityThreshold": 0.70
}
```

A `conversationId` returned by the first request can be supplied in later requests. Conversation access is restricted to the authenticated owner.

### Document ingestion
`POST /api/documents/upload` and `POST /api/documents/upload-many` accept PDFs up to 20 MB per file. The project remains hybrid: live legal information does not depend on uploading PDFs.

### Operational endpoints
- `/actuator/health`
- `/actuator/info`
- `/actuator/metrics`
- `/swagger-ui.html`
- `/v3/api-docs`

## Environment

Copy `.env.example` to `.env` and replace every placeholder. Never commit `.env` or production secrets.

Required:

```text
OPENAI_API_KEY
INDIAN_KANOON_API_TOKEN
JWT_SECRET
POSTGRES_PASSWORD
REDIS_PASSWORD
```

Generate a strong JWT secret rather than using the development default.

## Compatibility

- Backend: Java 21, Spring Boot 3.4.3, Spring AI 1.0.0-M6, Maven.
- Frontend: Node.js 20.14+ (Node 20.x), React 19, Vite 6, TypeScript 5.8.
- The frontend is pinned to Vite 6 because Vite 7 requires a newer Node 20 patch level than the Node 20.14.x environment used for this project.

## Local development

1. Start PostgreSQL and Redis:

```bash
docker compose up -d pgvector redis
```

2. Set environment variables.

3. Run the application:

```bash
mvn spring-boot:run
```

## Run the complete stack

```bash
docker compose up --build
```

## Tests

```bash
mvn test
```

## Production notes

- Put a TLS-terminating reverse proxy/load balancer in front of the application.
- Run multiple application replicas; Redis and PostgreSQL provide shared state.
- Use managed PostgreSQL/Redis or persistent volumes with backups in production.
- Rotate OpenAI, legal API, database, Redis and JWT secrets.
- Restrict Actuator exposure at the infrastructure layer and keep sensitive details disabled for anonymous users.
- Review Indian Kanoon API terms, rate limits, attribution and commercial requirements before production use.
- Legal answers should be presented as legal information, not a substitute for advice from a qualified advocate.

## Frontend and LLM streaming

The project now includes a React + Vite frontend under `frontend/`. It authenticates with the backend using JWT and renders LLM output token-by-token.

The streaming flow is:

```text
React UI
   |
   | POST /api/chat/stream
   v
Spring Boot ChatController
   |
   v
ChatService
   |
   v
Spring AI ChatClient.stream().content()
   |
   v
OpenAI streaming model
   |
   v
Server-Sent Events (SSE)
   |
   v
React UI renders each token immediately
```

The final SSE event contains the conversation ID and retrieved source metadata. Nginx has buffering disabled for `/api/chat/stream` so chunks are forwarded immediately.

Run locally:

```bash
cd frontend
npm install
npm run dev
```

Or run the complete stack:

```bash
docker compose up --build
```

Then open `http://localhost:5173`.


## Reliable local setup

This project is pinned to Spring Boot 3.4.3, Java 21, and Spring AI 1.0.0-M6.

### Option A — Docker for PostgreSQL + Redis, run backend/frontend from IntelliJ

1. Copy `.env.example` to `.env`.
2. Put your OpenAI API key in `.env` as `OPENAI_API_KEY=...`.
3. Indian Kanoon is optional. Leave `INDIAN_KANOON_API_TOKEN` empty to run without live legal search.
4. Start infrastructure:

```bash
docker compose up -d pgvector redis
```

5. Run the Spring Boot application from IntelliJ with Java 21.
6. Run the frontend:

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

The compose file exposes PostgreSQL on `localhost:5432` and Redis on `localhost:6379`, and the application defaults now match those development credentials.

### Option B — Run the complete stack with Docker

```bash
docker compose up --build
```

Open `http://localhost:5173`.

### Important

- A valid OpenAI API key is required for chat responses and PDF embedding/RAG.
- The Indian Kanoon token is only required when live legal search is enabled and you want real Indian Kanoon results.
- If you changed `JWT_SECRET`, delete the old browser token (or sign out/sign in again). The frontend now clears an invalid token automatically after a 401.
- For a clean PostgreSQL/PGVector reset during development:

```bash
docker compose down -v
docker compose up -d pgvector redis
```

- Do not commit `.env` or real API keys.

### Fixes included in this version

- Fixed frontend/backend conversation-ID mismatch that caused new chats to reference conversations that did not exist in PostgreSQL.
- Fixed blank `filterExpression` values being passed into Spring AI `SearchRequest`.
- Added the Spring AI M6 vector-store advisor dependency required by `QuestionAnswerAdvisor`.
- Fixed local PostgreSQL and Redis password mismatches between Docker Compose and `application.properties`.
- Exposed PostgreSQL/Redis ports so a backend launched from IntelliJ can use the Docker services.
- Made invalid/expired JWTs return HTTP 401 instead of silently falling through and producing confusing 403 responses.
- Added predictable security exception handling.
- Removed the manually forced multipart `Content-Type` header from the frontend upload request so the browser can generate the correct multipart boundary.
- Added basic multiple-upload validation.
- Removed the duplicate Vite React plugin dependency.
- Pinned Maven compilation to Java 21.
- Added the Spring milestone repository needed for the M6 dependency line.
